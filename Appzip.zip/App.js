import React, {Component} from 'react';
import DrawerNavigator from './components/DrawerNavigator';


import {StyleSheet, Text, View, TouchableHighlight} from 'react-native';



export default class App extends Component {
  render() {
    return (
    	
    
      <DrawerNavigator />
      
      
    );
  }
}