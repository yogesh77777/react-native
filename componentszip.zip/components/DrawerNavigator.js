import React, {Component} from 'react';
import { createAppContainer} from 'react-navigation';
import {createDrawerNavigator,DrawerItems} from 'react-navigation-drawer'
import HomeScreen from './HomeScreen';
import profile from './profile';
import bookmarks from './bookmarks'
import notifications from './notifications'
import {SafeAreaView,ScrollView,StyleSheet, Text,View, TouchableHighlight,Image,Button,Linking} from 'react-native'
import {Icon} from 'native-base'
import {createStackNavigator} from 'react-navigation-stack'
import videoplayer from './videoplayer'
import { DrawerActions, } from 'react-navigation-drawer';

const MyStackNavigator=createStackNavigator(
   {
  Home:{screen:HomeScreen,
     navigationOptions: {
        header:null
      },
  },
  videoplayer:{screen:videoplayer,
    navigationOptions: {
        header:null
      },
  }

   },

   {
    initialRouteName:'Home',
   
    });

const MyDrawerNavigator = createDrawerNavigator({
    

    Home1: {screen: HomeScreen,
        navigationOptions: {
        drawerLabel: <Icon style={{color:"#000080",backgroundColor:'#fff',fontSize:30,
         marginLeft:270}} name="arrow-back" />, 
      },
    },

    Home: {screen:MyStackNavigator,

       navigationOptions: {
        drawerLabel: 'Home',
        drawerIcon: ({ tintColor }) => (
          <Icon name='home'/>
       ) 
      },
    },

    

    profile: {screen: profile,
        navigationOptions:{
             drawerLabel:'Profile',
             drawerIcon: ({ tintColor }) => (
          <Icon name='person'/>
       )
        }
    },
    bookmarks:{screen:bookmarks,
       navigationOptions:{
             drawerLabel:'Bookmarks',
             drawerIcon: ({ tintColor }) => (
          <Icon name='bookmarks'/>
       )
        }

    },
    notifications:{screen:notifications,
       navigationOptions:{
             drawerLabel:'Notifications',
             drawerIcon: ({ tintColor }) => (
          <Icon name='notifications'/>
       )
        }

    },

},
{
    initialRouteName: 'Home',
    contentComponent: (props) => (
    <SafeAreaView >
        <View style={{height: 100,alignItems: 'center', justifyContent: 'center'}}>

          <Image style={{ height:225,width:225}}source={require('../assets/AV.png')}/>
        </View>
      <ScrollView>
        <DrawerItems {...props} />
      </ScrollView>
      <Text style={{color: '#000080',marginLeft:20,marginTop:170}}
      onPress={() => Linking.openURL('https://www.analyticsvidhya.com/terms/')}>
  Terms & condition 
</Text>
 <Text style={{color: '#000080',marginLeft:20,marginTop:20}}
      onPress={() => Linking.openURL('https://www.analyticsvidhya.com/privacy-policy/')}>
  Privacy Policy 
</Text>
    </SafeAreaView>
   ),
    drawerWidth: 300,
    drawerPosition: 'left',
}
);

const AppContainer = createAppContainer(MyDrawerNavigator);

export default class DrawerNavigator extends Component {
    render() {
        return <AppContainer />

    }
} 