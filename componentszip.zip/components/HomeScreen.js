import React, {Component} from 'react';
import {ActivityIndicator,FlatList,StyleSheet, Text, View, TouchableHighlight,Image,TouchableOpacity} from 'react-native';
import { DrawerActions, } from 'react-navigation-drawer';
import {Container, Header, Left, Body, Right, Button, Icon, Title,Content, Card, CardItem, Thumbnail } from 'native-base';
import {createAppContainer} from 'react-navigation'
import {createStackNavigator} from 'react-navigation-stack'
import videoplayer from './videoplayer'



export default class HomeScreen extends Component {
        static navigationOptions={
          home:'HomeScreen',
        }

        constructor(props){
        super(props)
        this.state={
            items:[]
        }
    }

    componentDidMount(){
        fetch('https://jsonplaceholder.typicode.com/photos')
        .then((response)=>response.json())
        .then((responseJson)=>{
          this.setState({
            items:responseJson
          })
        })
    }

    

    
    _renderItem=({item,index})=>{
        return(
          
         <TouchableOpacity onPress={() =>this.props.navigation.navigate('videoplayer')}>
         <Content style={{marginTop:30}}>
          <Card style={{flex: 0}}>
            <CardItem>
              <Left>
                  <Text style={{fontSize:21,marginTop:10}}>
                  {item.title}
                </Text>
              </Left>
            </CardItem>
            <CardItem>
              <Body>
                <Image source={{uri:item.url}} style={{height: 200, width:325, flex: 1}}/>
              </Body>
            </CardItem>
            <CardItem>
              <Left>
        
                  <Text style={{fontSize:20}}>10 videos</Text>
                
              </Left>
              <Right>
              <Button transparent>
                  <Icon name="bookmarks" style={{color:'black' , fontSize:25}} />
                  
                </Button>
              </Right>

            </CardItem>
          </Card>
        </Content>
        </TouchableOpacity>

            )
    }






    render() {
         let {items}=this.state
        if(items.length===0){
            return(
                <View style={{flex:1,alignItems:'center',justifyContent:'center'}}>
                <ActivityIndicator size="large"/>
                </View>
                )
        }
        return (
           <Container>
        <Header style={{backgroundColor:'#000080'}}>
          <Left>
            <Button transparent onPress={() => { this.props.navigation.dispatch(DrawerActions.openDrawer()); }}>
              <Icon name='menu' />
            </Button>
          </Left>
          <Body>
            <Title>Analytics Vidhya</Title>
          </Body>
          <Right>
           
          </Right>
        </Header>
      
       <FlatList
         data={items}
         keyExtractor={(item,index)=> index.toString()}
         renderItem={this._renderItem}
         />
       
        
      </Container>
         
       
        );
    }
}

const styles = StyleSheet.create({
    view: {
        flex: 1,
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: 'white',
    },
    text: {
        fontSize: 26,
        color: 'purple'
    },
    touchableHighlight: {
        width: 50,
        height: 50,
        backgroundColor: 'red',
        borderRadius: 50,
        alignItems: 'center',
        justifyContent: 'center',
        position: 'absolute', 
        left: 10, 
        top: 10,
    },
    open: {
        color: 'white', 
        fontSize: 40,
        fontWeight: 'bold',
    },
});