import React, {Component} from 'react';
import {StyleSheet, Text, View, TouchableHighlight} from 'react-native';
import {Container, Header, Left, Body, Right, Button, Icon, Title,Content, Card, CardItem, Thumbnail } from 'native-base';
export default class profile extends Component {
    render() {
        return (
            <View>
           <Header style={{backgroundColor:'#000080'}}>
          <Left>
            <Button transparent onPress={() => this.props.navigation.goBack()}>
              <Icon name='arrow-back' />
            </Button>
          </Left>
          <Body>
            <Title>Profile</Title>
          </Body>
          <Right>
           
          </Right>
        </Header>
            </View>
        );
    }
}


