import React, { Component } from 'react';
import { View, Text, StyleSheet, TouchableOpacity,FlatList } from 'react-native';
import YouTube from 'react-native-youtube';



export default class videoplayer extends Component {



 constructor(props) {
    super(props);
    this.state = {
        isReady: false,
        status: "",
        quality: "",
        error: "",
        id:"FR4QIeZaPeM",
        title:"Introduction to SQL",
        videoIndex:0,
    },
    this.tempArray=[
      {
    "id": 1,
    "title": "Introduction to SQL",
    "url": "https://www.youtube.com/watch?v=FR4QIeZaPeM",
      },
      
        {
      "id": 2,
      "title": "Introduction to Machine learninig",
      "url": "https://www.youtube.com/watch?v=6Hm1pNqQxq0",
        },

        {
      "id": 3,
      "title": "Introduction to Neural Network",
      "url": "https://www.youtube.com/watch?v=aircAruvnKk",
        },
        {
      "id": 4,
      "title": "Introduction to Data Science",
      "url": "https://www.youtube.com/watch?v=UXi8Ml2UoYk",
        },
    ]
  }

  _renderItem=({item,index}) =>{
    return (
       <View style={styles.card}>

    <Text style={styles.cardText}  
    onPress={() => {
      VID_REGEX = /(?:youtube(?:-nocookie)?\.com\/(?:[^\/\n\s]+\/\S+\/|(?:v|e(?:mbed)?)\/|\S*?[?&]v=)|youtu\.be\/)([a-zA-Z0-9_-]{11})/;

    this.setState({id:(item.url).match(VID_REGEX)[1]});
    this.setState({title:item.title});
    this.setState({videoIndex:index});
  }}>

    {item.id+". "+item.title}</Text>          
        </View>
    )
  }




  render() {
    return (
      <View style={styles.container}>
        
        {/* <Text>{`Status: ${this.state.status}`}</Text> */}

        <YouTube
      apiKey="AIzaSyD9tw299qat2EQUmAWx-leZIPMtLM-3_Pc"
      videoId={this.state.id} // The YouTube video ID
      play // control playback of video with true/false
      fullscreen={false} // video should play in fullscreen or inline
      loop={false} // control whether the video should loop when ended
      onReady={e => this.setState({ isReady: true })}
      onChangeState={e => this.setState({ status: e.state })}
      onChangeQuality={e => this.setState({ quality: e.quality })}
      onError={e => this.setState({ error: e.error })}
      style={styles.youtube}
      onEnd={() =>{
        console.log("Video is ended");
        VID_REGEX = /(?:youtube(?:-nocookie)?\.com\/(?:[^\/\n\s]+\/\S+\/|(?:v|e(?:mbed)?)\/|\S*?[?&]v=)|youtu\.be\/)([a-zA-Z0-9_-]{11})/;
         this.setState({videoIndex:(parseInt(this.state.videoIndex)+1)%(this.tempArray.length)})
         this.setState({id:(this.tempArray[this.state.videoIndex].url).match(VID_REGEX)[1]});
         this.setState({title:(this.tempArray[this.state.videoIndex].title)});
      }}
    /> 

    <Text>{this.state.title}</Text>
        
          <FlatList
          data={this.tempArray}
          renderItem={this._renderItem}
          keyExtractor={(item,index)=> index.toString()}
          />
    
      </View>
      
    );
  }
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
    },
    youtube: {
    alignSelf: 'stretch',
    height: 300
    },
    cardText:{
      fontSize:16,
      padding:10,
    },
    card:{
      backgroundColor:'#fff',
      marginBottom:10,
      marginLeft:'2%',      
      width:'96%',
      shadowColor:'#000',
      shadowOpacity:1,
      shadowOffset:{
        width:3,
        height:3
      }
    }
});